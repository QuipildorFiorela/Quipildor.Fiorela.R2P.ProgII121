
package service;

@FunctionalInterface
public interface CSVSerializable<T> {
    String toCSV(); 
}
