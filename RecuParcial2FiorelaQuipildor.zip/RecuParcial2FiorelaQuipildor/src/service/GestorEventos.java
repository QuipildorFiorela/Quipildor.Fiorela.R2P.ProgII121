
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.util.Comparator;

import java.util.ArrayList;
import java.util.List;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

import java.io.IOException;
import java.time.LocalDate;
import modelo.Evento;

public class GestorEventos <T extends Evento & CSVSerializable> implements Gestable<T> {
    
    List<T> inventario = new ArrayList<>();

    @Override
    public void agregar(T item) {
        inventario.add(item);
    }

    @Override
    public T obtener(int indice) {
        return inventario.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        inventario.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado) {
        List<T> toReturn = new ArrayList<>();
        for (T item : inventario) {
            if (predicado.test(item)) {
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    @Override
    public void ordenarNatural() {
        ordenar((Comparator<T>) Comparator.naturalOrder()); //Devuelve un Comparator que utiliza el orden natural definido en EventoMusicall (implementado en compareTo)
    }

    @Override
    public void ordenar(Comparator<T> comparador) { //ordena la inventario no solo por el orden natural, sino también utilizando cualquier criterio
        inventario.sort(comparador);
    }

    @Override
    public void serializar(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(inventario);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public List<T> deserializar(String path) {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            inventario = (List<T>) input.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        return inventario;
    }

    @Override
    public void guardarCSV(String path) {
        File archivo = new File(path);
        if (!archivo.exists()) {
            try {
                archivo.createNewFile();
            } catch (IOException e) {
                System.out.println("Error al crear el archivo: " + e.getMessage());
                throw new RuntimeException("El archivo ya existe!!!");
            }
        }
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id,nombre,especie,alimentacion\n");
            for (T item : inventario) {
                bw.write(item.toCSV() + "\n");
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error al guardar en el archivo!!");
        }
    }

    @Override
    public void cargarCSV(String path, Function<String, T> funcion) { // recibe string y devuelvo T
        File archivo = new File(path);

        if (!archivo.exists()) {
            System.out.println("El archivo no existe!!!");
            throw new RuntimeException("Error: El archivo no existe!!!");
        }
        inventario.clear();
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine(); // Lee la cabecera
            while ((linea = bf.readLine()) != null) {
                inventario.add(funcion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("ERROR!!!");
        }
    }

    @Override
    public void paraCadaElemento(Consumer<T> consumer) { //El consumer acepta un argumento (T, en este caso tipo EventoMusical) y realiza una operación, pero no devuelve ningún valor
        for (T item : inventario) {
            consumer.accept(item); //Para cada elemento item, ejecuta consumer.accept(item), que aplica la función que defina yo al momento de implementarla
        }
    }

    @Override
    public void limpiar() {
        inventario.clear();
    }

    @Override
    public void mostrarTodos() {
        inventario.forEach(System.out::println);
    }

  @Override
    public List<T> buscarPorRango(LocalDate inicio, LocalDate fin) {
        return filtrar(e -> e.getFecha().isBefore(fin) && e.getFecha().isAfter(inicio)); //antes del final y despues del inicio
    }
    
}
