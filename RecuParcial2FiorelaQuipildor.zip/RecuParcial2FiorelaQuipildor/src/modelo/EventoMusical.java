
package modelo;

import java.time.LocalDate;
import service.CSVSerializable;

public class EventoMusical extends Evento implements Comparable<EventoMusical>, CSVSerializable {
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }
    
    
@Override
    public int compareTo(EventoMusical o) {
        return this.getFecha().compareTo(o.getFecha());
    }

    @Override
    public String toString() {
        return  super.toString() + ", artista=" + artista + ", genero=" + genero + '}';
    }
    
    
    @Override
    public String toCSV() {
        return getId() + "," + getNombre() + "," + getFecha() + "," + artista + "," + genero ;
    }
    
    public static EventoMusical fromCSV(String eventoMusicalCSV) {
        if (eventoMusicalCSV.endsWith("\n")) {
            eventoMusicalCSV = eventoMusicalCSV.substring(0, eventoMusicalCSV.length() - 1);
        }
        String[] data = eventoMusicalCSV.split(",");
                    int id = Integer.parseInt(data[0]);
                    String nombre = data[1];
                    LocalDate fecha = LocalDate.parse(data[2]);
                    String artista = data[3];
                    GeneroMusical genero =GeneroMusical.valueOf(data[4]);
                    
                   return new EventoMusical(id, nombre, fecha, artista, genero);
            }

  
}        
