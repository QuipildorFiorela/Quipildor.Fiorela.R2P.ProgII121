
package config;

public class AppConstants {
    
    public static final String PATH_ARCHIVOS = "src/data/";
    public static final String SERIAL = PATH_ARCHIVOS + "eventos.bin";
    public static final String CSV = PATH_ARCHIVOS + "eventos.csv";

}
